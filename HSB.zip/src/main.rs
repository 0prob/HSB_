use anyhow::Result;
use dotenvy::dotenv;
use tokio::time::{sleep, Duration};
use tracing_subscriber::EnvFilter;

use arbitrage_engine::engine::{
    arb::ArbEngine,
    decimals::DecimalsCache,
    gas::GasModel,
    pricing::PricingEngine,
    registry::PairRegistry,
    snapshot::RpcSnapshot,
};
use arbitrage_engine::types::ChainConfig;

fn load_chain(path: &str) -> Result<ChainConfig> {
    let raw = std::fs::read_to_string(path)?;
    let cfg: ChainConfig = toml::from_str(&raw)?;
    Ok(cfg)
}

#[tokio::main]
async fn main() -> Result<()> {
    dotenv().ok();

    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::from_default_env())
        .init();

    let polygon = load_chain("config/polygon.toml")?;
    let chains = vec![polygon];

    let registry = PairRegistry::new();
    let pricing = PricingEngine::new();

    // HyperSync subscriber (pool discovery + swap streaming)
    for chain in chains.clone() {
        let reg = registry.clone();
        let pr = pricing.clone();
        tokio::spawn(async move {
            let _ = arbitrage_engine::hypersync::subscriber::run_hypersync_subscriber(chain, reg, pr).await;
        });
    }

    // Arb engine
    for chain in chains.clone() {
        if !chain.enabled {
            continue;
        }

        let reg = registry.clone();
        let pr = pricing.clone();

        let gas = GasModel::from_chain_config(&chain, 1.0);
        let dec = DecimalsCache::new(&chain.rpc_url)?;
        let snap = RpcSnapshot::new(&chain.rpc_url)?;

        let engine = ArbEngine::new(chain.clone(), reg, pr, dec, snap, gas);

        tokio::spawn(async move {
            loop {
                let _ = engine.act().await;
                sleep(Duration::from_millis(500)).await;
            }
        });
    }

    loop {
        sleep(Duration::from_secs(60)).await;
    }
}
