use anyhow::{anyhow, Result};
use graphql_client::GraphQLQuery;
use reqwest::Client;
use tokio::time::{sleep, Duration};

use crate::engine::registry::PairRegistry;
use crate::types::{ChainConfig, PairMeta};

use super::graphql::{all_pairs, AllPairs};

async fn introspect_has_field(client: &Client, url: &str, field: &str) -> Result<bool> {
    let q = r#"
      query Introspect {
        __schema { queryType { fields { name } } }
      }
    "#;

    let resp = client
        .post(url)
        .timeout(Duration::from_secs(10))
        .json(&serde_json::json!({ "query": q, "variables": {} }))
        .send()
        .await?;

    let status = resp.status();
    let v: serde_json::Value = resp.json().await?;

    if !status.is_success() {
        return Err(anyhow!("HyperIndex HTTP {}: {}", status, v));
    }

    if v.get("errors").is_some() {
        return Err(anyhow!("HyperIndex introspection errors: {}", v["errors"]));
    }

    let arr = v["data"]["__schema"]["queryType"]["fields"]
        .as_array()
        .ok_or_else(|| anyhow!("Bad introspection shape: {}", v))?;

    Ok(arr.iter().any(|x| x["name"].as_str() == Some(field)))
}

pub async fn run_hyperindex_discovery(
    chain: ChainConfig,
    registry: PairRegistry,
    client: Client,
) -> Result<()> {
    if !chain.enabled {
        tracing::info!("HyperIndex disabled for chain {}", chain.name);
        return Ok(());
    }

    tracing::info!("Starting HyperIndex discovery for {}", chain.name);
    tracing::info!("HyperIndex URL for {}: {}", chain.name, chain.hyperindex_url);

    // Hard fail if endpoint doesn't match expected schema.
    let ok = introspect_has_field(&client, &chain.hyperindex_url, "pairCreateds").await?;
    if !ok {
        return Err(anyhow!(
            "HyperIndex endpoint schema mismatch: query_root lacks 'pairCreateds'. \
             You are pointing at the wrong HyperIndex project URL: {}",
            chain.hyperindex_url
        ));
    }

    loop {
        let vars = all_pairs::Variables {};
        let body = AllPairs::build_query(vars);

        let resp = client
            .post(chain.hyperindex_url.clone())
            .timeout(Duration::from_secs(10))
            .json(&body)
            .send()
            .await?
            .error_for_status()?
            .json::<graphql_client::Response<all_pairs::ResponseData>>()
            .await?;

        if let Some(errs) = resp.errors.as_ref() {
            tracing::error!("HyperIndex GraphQL errors on {}: {:?}", chain.name, errs);
        }

        let data = match resp.data {
            Some(d) => d,
            None => {
                tracing::warn!("HyperIndex returned no data on {}", chain.name);
                sleep(Duration::from_secs(30)).await;
                continue;
            }
        };

        let mut inserted = 0usize;
        for row in data.pair_createds {
            let pool = match row.pair.parse() { Ok(a) => a, Err(_) => continue };
            let token0 = match row.token0.parse() { Ok(a) => a, Err(_) => continue };
            let token1 = match row.token1.parse() { Ok(a) => a, Err(_) => continue };

            registry.insert(PairMeta {
                chain: chain.name.clone(),
                dex: row.dex,
                pool,
                token0,
                token1,
                fee_tier: None,
            });
            inserted += 1;
        }

        tracing::info!("HyperIndex inserted {} pools for {}", inserted, chain.name);
        sleep(Duration::from_secs(60)).await;
    }
}
