use anyhow::Result;

use hypersync_client::net_types::LogFilter;

use crate::engine::registry::PairRegistry;
use crate::types::ChainConfig;

fn topic0(sig: &str) -> String {
    // topic0 = keccak256(event_signature) as 0x-prefixed hex string
    let h = ethers::utils::keccak256(sig.as_bytes());
    format!("0x{}", ethers::utils::hex::encode(h))
}

/// Polygon + UniswapV2 + Algebra only.
pub fn build_filter(chain: &ChainConfig, registry: &PairRegistry) -> Result<LogFilter> {
    let addrs: Vec<String> = registry
        .by_chain(&chain.name)
        .iter()
        .map(|p| format!("{:#x}", p.pool))
        .collect();

    let topics0 = vec![
        topic0("Swap(address,uint256,uint256,uint256,uint256,address)"), // UniV2 Swap
        topic0("Sync(uint112,uint112)"), // UniV2 Sync
        topic0("Swap(address,address,int256,int256,uint160,uint128,int24)"), // Algebra Swap
    ];

    let f = LogFilter::all()
        .and_address(addrs)?
        .and_topic0(topics0)?;

    Ok(f)
}
