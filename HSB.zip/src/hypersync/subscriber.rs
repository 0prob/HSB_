use anyhow::{anyhow, Result};
use tokio::time::{sleep, Duration};

use ethers::types::{Address, H256};

use hypersync_client::{
    net_types::{LogField, LogFilter, Query},
    Client as HsClient,
    StreamConfig,
};

use crate::engine::pricing::PricingEngine;
use crate::engine::registry::PairRegistry;
use crate::types::{ChainConfig, PairMeta};

use crate::universe::filter::UniverseFilter;

use super::decode::decode_log;
use super::filters::build_filter;

// ----------------------
// Polygon factories
// ----------------------

const QS_V2_FACTORY: &str = "0x5757371414417b8c6caad45baef941abc7d3ab32";
const QS_ALG_FACTORY: &str = "0x411b0fAcC3489691f28ad58c47006AF5E3Ab3A28";

// keccak256("PairCreated(address,address,address,uint256)")
const TOPIC_PAIR_CREATED: &str =
    "0x0d3648bd0f6ba80134a33ba9275ac585d9d315f0ad8355cddefde31afa28d0e9";

fn topic_pool() -> String {
    let h = ethers::utils::keccak256("Pool(address,address,address)".as_bytes());
    format!("0x{}", ethers::utils::hex::encode(h))
}

fn h256_from_hex(s: &str) -> Result<H256> {
    Ok(s.parse::<H256>()
        .map_err(|e| anyhow!("bad topic hex {}: {:?}", s, e))?)
}

fn addr_from_hex(s: &str) -> Result<Address> {
    Ok(s.parse::<Address>()
        .map_err(|e| anyhow!("bad address {}: {:?}", s, e))?)
}

fn topic_to_addr(t: &H256) -> Address {
    Address::from_slice(&t.as_bytes()[12..32])
}

fn data_word_to_addr(data: &[u8], word_index: usize) -> Option<Address> {
    let start = word_index * 32;
    if data.len() < start + 32 {
        return None;
    }
    Some(Address::from_slice(&data[start + 12..start + 32]))
}

/// Discover pools via factory events, applying UniverseFilter before inserting.
async fn discover_pools_from_factories(
    client: &HsClient,
    chain: &ChainConfig,
    registry: &PairRegistry,
    universe: &UniverseFilter,
    from_block: u64,
    window: u64,
) -> Result<u64> {
    let factories = vec![QS_V2_FACTORY.to_string(), QS_ALG_FACTORY.to_string()];
    let topics0 = vec![TOPIC_PAIR_CREATED.to_string(), topic_pool()];

    let filter = LogFilter::all()
        .and_address(factories)?
        .and_topic0(topics0)?;

    let query = Query::new()
        .from_block(from_block)
        .to_block_excl(from_block.saturating_add(window))
        .where_logs(filter)
        .select_log_fields([
            LogField::Address,
            LogField::Topic0,
            LogField::Topic1,
            LogField::Topic2,
            LogField::Data,
            LogField::BlockNumber,
            LogField::TransactionHash,
        ]);

    let mut rx = client.stream(query, StreamConfig::default()).await?;

    let mut next_block = from_block;

    let pair_created_t0 = h256_from_hex(TOPIC_PAIR_CREATED)?;
    let pool_t0 = h256_from_hex(&topic_pool())?;

    while let Some(msg) = rx.recv().await {
        let resp = msg?;
        next_block = resp.next_block;

        for batch in resp.data.logs {
            for lg in batch {
                // Registry cap (Universe-configured)
                if registry.by_chain(&chain.name).len() >= universe.max_pools() {
                    return Ok(next_block);
                }

                let factory = match lg.address.as_ref() {
                    Some(a) => Address::from_slice(a.as_ref()),
                    None => continue,
                };

                let t0 = match lg.topics.get(0).and_then(|x| x.as_ref()) {
                    Some(x) => H256::from_slice(x.as_ref()),
                    None => continue,
                };
                let t1 = match lg.topics.get(1).and_then(|x| x.as_ref()) {
                    Some(x) => H256::from_slice(x.as_ref()),
                    None => continue,
                };
                let t2 = match lg.topics.get(2).and_then(|x| x.as_ref()) {
                    Some(x) => H256::from_slice(x.as_ref()),
                    None => continue,
                };

                let data = match lg.data.as_ref() {
                    Some(d) => d.as_ref(),
                    None => continue,
                };

                // QuickSwap V2 PairCreated
                if t0 == pair_created_t0 && factory == addr_from_hex(QS_V2_FACTORY)? {
                    let token0 = topic_to_addr(&t1);
                    let token1 = topic_to_addr(&t2);
                    let pair = match data_word_to_addr(data, 0) {
                        Some(a) => a,
                        None => continue,
                    };

                    let meta = PairMeta {
                        chain: chain.name.clone(),
                        dex: "quickswap_v2".to_string(),
                        pool: pair,
                        token0,
                        token1,
                        fee_tier: None,
                    };

                    if universe.accept_pair(&meta) {
                        registry.insert(meta);
                    }
                }

                // QuickSwap Algebra pool-created
                if t0 == pool_t0 && factory == addr_from_hex(QS_ALG_FACTORY)? {
                    let token0 = topic_to_addr(&t1);
                    let token1 = topic_to_addr(&t2);
                    let pool = match data_word_to_addr(data, 0) {
                        Some(a) => a,
                        None => continue,
                    };

                    let meta = PairMeta {
                        chain: chain.name.clone(),
                        dex: "quickswap_algebra".to_string(),
                        pool,
                        token0,
                        token1,
                        fee_tier: None,
                    };

                    if universe.accept_pair(&meta) {
                        registry.insert(meta);
                    }
                }
            }
        }
    }

    Ok(next_block)
}

pub async fn run_hypersync_subscriber(
    chain: ChainConfig,
    registry: PairRegistry,
    pricing: PricingEngine,
) -> Result<()> {
    if !chain.enabled {
        tracing::info!("HyperSync disabled for chain {}", chain.name);
        return Ok(());
    }

    tracing::info!("Starting HyperSync subscriber for {}", chain.name);

    let universe = UniverseFilter::from_chain(&chain)?;

    let mut builder = HsClient::builder().chain_id(chain.chain_id);
    if let Ok(tok) = std::env::var("ENVIO_API_TOKEN") {
        builder = builder.api_token(tok);
    }
    let client = builder.build()?;

    let mut from_block: u64 = std::env::var("HYPERSYNC_FROM_BLOCK")
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(60_000_000);

    let window: u64 = std::env::var("HYPERSYNC_WINDOW_BLOCKS")
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(50_000);

    // Phase 1: discover pools via factories (UniverseFilter applied)
    loop {
        let pool_count = registry.by_chain(&chain.name).len();
        if pool_count > 0 {
            tracing::info!(
                "Discovered {} pools for {}; switching to swap streaming.",
                pool_count,
                chain.name
            );
            break;
        }

        tracing::info!(
            "Discovering pools from factories on {} from_block={} window={}",
            chain.name,
            from_block,
            window
        );

        from_block = discover_pools_from_factories(&client, &chain, &registry, &universe, from_block, window).await?;
        sleep(Duration::from_millis(250)).await;
    }

    // Phase 2: stream swaps/syncs for discovered pools
    loop {
        let pool_count = registry.by_chain(&chain.name).len();
        if pool_count == 0 {
            sleep(Duration::from_secs(1)).await;
            continue;
        }

        let filter = build_filter(&chain, &registry)?;
        tracing::info!("Streaming swaps for {} pools on {}", pool_count, chain.name);

        let query = Query::new()
            .from_block(from_block)
            .to_block_excl(from_block.saturating_add(window))
            .where_logs(filter)
            .select_log_fields([
                LogField::Address,
                LogField::Topic0,
                LogField::Topic1,
                LogField::Topic2,
                LogField::Topic3,
                LogField::Data,
                LogField::TransactionHash,
                LogField::BlockNumber,
            ]);

        let mut rx = client.stream(query, StreamConfig::default()).await?;

        while let Some(msg) = rx.recv().await {
            let resp = msg?;
            from_block = resp.next_block;

            for batch in resp.data.logs {
                for lg in batch {
                    let reg = registry.clone();
                    let pr = pricing.clone();
                    let chain_name = chain.name.clone();
                    tokio::spawn(async move {
                        if let Err(e) = decode_log(chain_name, lg, reg, pr).await {
                            tracing::error!("Decode error: {:?}", e);
                        }
                    });
                }
            }
        }

        sleep(Duration::from_millis(250)).await;
    }
}
