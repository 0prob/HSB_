use ethers::types::Address;

use crate::engine::pricing::PricingEngine;
use crate::engine::registry::PairRegistry;

#[derive(Debug, Clone)]
pub struct Route {
    pub pools: Vec<Address>,   // length 2 for linear cycle
    pub tokens: Vec<Address>,  // [A, B, A]
    pub price: f64,            // composite multiplier (rough)
}

#[derive(Debug, Clone)]
pub struct TriRoute {
    pub pools: [Address; 3],
    pub tokens: [Address; 3], // [A,B,C]
    pub composite_price: f64,
}

pub struct RoutePlanner {
    registry: PairRegistry,
    pricing: PricingEngine,
}

impl RoutePlanner {
    pub fn new(registry: PairRegistry, pricing: PricingEngine) -> Self {
        Self { registry, pricing }
    }

    fn pool_dir_price(&self, pool: Address, token_in: Address, token_out: Address) -> Option<f64> {
        let meta = self.registry.get(&pool)?;
        let p = self.pricing.get_price(&pool)?.price;
        if p <= 0.0 {
            return None;
        }

        if token_in == meta.token0 && token_out == meta.token1 {
            Some(p)
        } else if token_in == meta.token1 && token_out == meta.token0 {
            Some(1.0 / p)
        } else {
            None
        }
    }

    /// Build 2-pool cyclic routes only: A -> B -> A
    pub fn build_routes(&self, chain: &str, max_hops: usize) -> Vec<Route> {
        if max_hops < 2 {
            return vec![];
        }

        let metas = self.registry.by_chain(chain);
        let mut out = Vec::new();

        for p1 in &metas {
            for p2 in &metas {
                if p1.pool == p2.pool {
                    continue;
                }

                // Need reserves/prices for both pools
                if self.pricing.get_price(&p1.pool).is_none() || self.pricing.get_price(&p2.pool).is_none() {
                    continue;
                }

                let p1_dirs = [(p1.token0, p1.token1), (p1.token1, p1.token0)];
                let p2_dirs = [(p2.token0, p2.token1), (p2.token1, p2.token0)];

                for (a, b) in p1_dirs {
                    let p_ab = match self.pool_dir_price(p1.pool, a, b) {
                        Some(x) => x,
                        None => continue,
                    };

                    for (b2, a2) in p2_dirs {
                        // enforce cycle: A->B then B->A
                        if b2 != b || a2 != a {
                            continue;
                        }

                        let p_ba = match self.pool_dir_price(p2.pool, b, a) {
                            Some(x) => x,
                            None => continue,
                        };

                        out.push(Route {
                            pools: vec![p1.pool, p2.pool],
                            tokens: vec![a, b, a],
                            price: p_ab * p_ba,
                        });
                    }
                }
            }
        }

        out
    }

    /// Keep triangular builder (not yet executed realistically)
    pub fn build_triangular_routes(&self, chain: &str) -> Vec<TriRoute> {
        let metas = self.registry.by_chain(chain);
        let mut out = Vec::new();

        for p1 in &metas {
            for p2 in &metas {
                if p2.pool == p1.pool {
                    continue;
                }
                for p3 in &metas {
                    if p3.pool == p1.pool || p3.pool == p2.pool {
                        continue;
                    }

                    if self.pricing.get_price(&p1.pool).is_none()
                        || self.pricing.get_price(&p2.pool).is_none()
                        || self.pricing.get_price(&p3.pool).is_none()
                    {
                        continue;
                    }

                    let d1 = [(p1.token0, p1.token1), (p1.token1, p1.token0)];
                    let d2 = [(p2.token0, p2.token1), (p2.token1, p2.token0)];
                    let d3 = [(p3.token0, p3.token1), (p3.token1, p3.token0)];

                    for (a, b) in d1 {
                        let p_ab = match self.pool_dir_price(p1.pool, a, b) {
                            Some(x) => x,
                            None => continue,
                        };

                        for (b2, c) in d2 {
                            if b2 != b {
                                continue;
                            }
                            let p_bc = match self.pool_dir_price(p2.pool, b, c) {
                                Some(x) => x,
                                None => continue,
                            };

                            for (c2, a2) in d3 {
                                if c2 != c || a2 != a {
                                    continue;
                                }
                                let p_ca = match self.pool_dir_price(p3.pool, c, a) {
                                    Some(x) => x,
                                    None => continue,
                                };

                                out.push(TriRoute {
                                    pools: [p1.pool, p2.pool, p3.pool],
                                    tokens: [a, b, c],
                                    composite_price: p_ab * p_bc * p_ca,
                                });
                            }
                        }
                    }
                }
            }
        }

        out
    }
}
