use anyhow::Result;
use dashmap::DashMap;
use ethers::types::{Address, U256};
use std::sync::{
    atomic::{AtomicU64, Ordering},
    Arc,
};

use crate::types::SwapEvent;

#[derive(Debug, Clone)]
pub struct PoolPrice {
    pub price: f64,
    pub liquidity: Option<U256>,
    pub tick: Option<i32>,

    // UniV2 reserves (token0/token1 per PairMeta)
    pub reserve0: Option<U256>,
    pub reserve1: Option<U256>,

    // Freshness tracking (block number of last Sync)
    pub last_sync_block: Option<u64>,
}

#[derive(Clone)]
pub struct PricingEngine {
    inner: Arc<DashMap<Address, PoolPrice>>,
    latest_block: Arc<AtomicU64>,
}

impl PricingEngine {
    pub fn new() -> Self {
        Self {
            inner: Arc::new(DashMap::new()),
            latest_block: Arc::new(AtomicU64::new(0)),
        }
    }

    fn bump_latest_block(&self, bn: u64) {
        let cur = self.latest_block.load(Ordering::Relaxed);
        if bn > cur {
            self.latest_block.store(bn, Ordering::Relaxed);
        }
    }

    pub fn latest_observed_block(&self) -> u64 {
        self.latest_block.load(Ordering::Relaxed)
    }

    fn upsert(&self, pool: Address, mut f: impl FnMut(&mut PoolPrice)) {
        self.inner
            .entry(pool)
            .and_modify(|v| f(v))
            .or_insert_with(|| {
                let mut v = PoolPrice {
                    price: 0.0,
                    liquidity: None,
                    tick: None,
                    reserve0: None,
                    reserve1: None,
                    last_sync_block: None,
                };
                f(&mut v);
                v
            });
    }

    pub fn get_price(&self, pool: &Address) -> Option<PoolPrice> {
        self.inner.get(pool).map(|v| v.clone())
    }

    pub fn get_v2_reserves(&self, pool: &Address) -> Option<(U256, U256)> {
        let p = self.inner.get(pool)?;
        Some((p.reserve0?, p.reserve1?))
    }

    pub fn get_v2_last_sync_block(&self, pool: &Address) -> Option<u64> {
        let p = self.inner.get(pool)?;
        p.last_sync_block
    }

    // -----------------------------
    // Uniswap V2: price from Sync only
    // -----------------------------
    pub async fn update_v2_swap(&self, _ev: SwapEvent) -> Result<()> {
        Ok(())
    }

    pub async fn update_v2_sync(&self, ev: SwapEvent) -> Result<()> {
        self.bump_latest_block(ev.block_number);

        if let (Some(r0), Some(r1)) = (ev.reserve0, ev.reserve1) {
            if r0.is_zero() || r1.is_zero() {
                return Ok(());
            }

            let p = r1.as_u128() as f64 / r0.as_u128() as f64;
            if !(1e-12..=1e12).contains(&p) {
                return Ok(());
            }

            let bn = ev.block_number;

            self.upsert(ev.pool, |st| {
                st.price = p;
                st.reserve0 = Some(r0);
                st.reserve1 = Some(r1);
                st.last_sync_block = Some(bn);
                st.tick = None;
                st.liquidity = None;
            });
        }
        Ok(())
    }

    // -----------------------------
    // Algebra: keep tick-based placeholder (not used for execution yet)
    // -----------------------------
    pub async fn update_algebra(&self, ev: SwapEvent) -> Result<()> {
        self.bump_latest_block(ev.block_number);

        if let Some(tick) = ev.tick {
            let price = tick_to_price(tick);
            if !(1e-12..=1e12).contains(&price) {
                return Ok(());
            }
            self.upsert(ev.pool, |st| {
                st.price = price;
                st.tick = Some(tick);
                st.liquidity = Some(ev.liquidity.unwrap_or_default());
            });
        }
        Ok(())
    }
}

fn tick_to_price(tick: i32) -> f64 {
    const BASE: f64 = 1.0001;
    BASE.powi(tick)
}
