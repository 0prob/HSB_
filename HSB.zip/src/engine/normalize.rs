use anyhow::Result;

use crate::engine::pricing::PricingEngine;
use crate::types::{SwapEvent, SwapType};

/// Normalize decoded events into pricing updates.
/// Scope: Polygon + UniswapV2 + Algebra only.
pub async fn normalize_and_update(pricing: &PricingEngine, ev: SwapEvent) -> Result<()> {
    match ev.event_type {
        // UniV2: ignore Swap for pricing; use Sync for reserves/pricing
        SwapType::UniswapV2Swap => {
            pricing.update_v2_swap(ev).await?;
        }
        SwapType::UniswapV2Sync => {
            pricing.update_v2_sync(ev).await?;
        }

        // Algebra: tick/liquidity placeholder update (not executed yet)
        SwapType::AlgebraSwap => {
            pricing.update_algebra(ev).await?;
        }

        // Everything else not supported in this build
        _ => {}
    }

    Ok(())
}
